package com.exam.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;


public class DBManager2 {
	static Connection getConnection() throws Exception{
			
			//DB접속정보
			 String url = "jdbc:oracle:thin:@localhost:1521:xe";
			 String user = "scott";
			 String password = "tiger";
			 
			Connection con = null;
			//1단계: DB 드라이버 로딩
			Class.forName("oracle.jdbc.OracleDriver");
			//2단계: DB연결
			con = DriverManager.getConnection(url, user, password);
			return con;
		}// static method
		
	// SELECT문을 수행한 후 리소스 해제를 위한 메소드
	public static void close(Connection con, Statement stmt,ResultSet rs){		
		if (rs != null) { 
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}// rs.close method
		if (stmt != null) {
			try {
				stmt.close();
			}catch (SQLException e) {
				e.printStackTrace();
			}
		}// stmt.close method
		if (con != null) {
			try {
				con.close();
			}catch (SQLException e) {
				e.printStackTrace();
			}
		}// con.close method
	}// close method
	public static void close(Connection con, Statement stmt){		
		if (stmt != null) {
			try {
				stmt.close();
			}catch (SQLException e) {
				e.printStackTrace();
			}
		}// stmt.close method
		if (con != null) {
			try {
				con.close();
			}catch (SQLException e) {
				e.printStackTrace();
			}
		}// con.close method
	}// close method
	
	
	
} // class method
