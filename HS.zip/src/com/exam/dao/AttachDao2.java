package com.exam.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import javax.xml.transform.Result;

import com.exam.vo.AttachVO2;

public class AttachDao2 {
	
	private static AttachDao2 instance = new AttachDao2();
	
	public static AttachDao2 getInstance() {
		return instance;
	}
	
	private AttachDao2() {}
		
	
	// 첨부파일정보 입력하기 메소드
	public void insertAttach(AttachVO2 attachVO2) {
		Connection con = null;
		PreparedStatement pstmt = null;
		try {
			con = DBManager2.getConnection();
			String sql = "INSERT INTO attach2 (uuid, filename, filetype, bno) ";
			sql += "VALUES (?, ?, ?, ?)";
			
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, attachVO2.getUuid());
			pstmt.setString(2, attachVO2.getFilename());
			pstmt.setString(3, attachVO2.getFiletype());
			pstmt.setInt(4, attachVO2.getBno());
			// 실해
			pstmt.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBManager2.close(con, pstmt);
		}
			
		}// insertAttach method
	
		
	// 글번호에 해당하는 첨부파일정보 가져오기
	public List<AttachVO2> getAttaches(int bno){
		List<AttachVO2> list = new ArrayList<AttachVO2>();
		
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		try {
			con = DBManager2.getConnection();
			
			String sql = "SELECT * FROM attach2 WHERE bno = ?";
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, bno);
			// 실행
			rs = pstmt.executeQuery();
			while (rs.next()) {
				AttachVO2 attachVO2 = new AttachVO2();
				attachVO2.setBno(rs.getInt("bno"));
				attachVO2.setUuid(rs.getString("uuid"));
				attachVO2.setFilename(rs.getString("filename"));
				attachVO2.setFiletype(rs.getString("filetype"));
				
				list.add(attachVO2);
			} // while
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBManager2.close(con, pstmt, rs);
		}
		return list;
	} // getAttach method
	
	
	// 게시판 글번호에 해당하는 첨부파일정보 삭제하는 메소드
	public void deleteAttach(int bno) {
		Connection con = null;
		PreparedStatement pstmt = null;
		
		try {
			con = DBManager2.getConnection();
			String sql = "DELETE FROM attach2 WHERE bno = ? ";
			
			pstmt =con.prepareStatement(sql);
			pstmt.setInt(1, bno);
			//실행
			pstmt.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBManager2.close(con, pstmt);
		}
	} // deleteAttach method
	
	// uuid에 해당하는 첨부파일정보 한개 삭제하는 메소드
	public void deleteAttach(String uuid) {
		Connection con = null;
		PreparedStatement pstmt = null;
		
		try {
			con = DBManager2.getConnection();
			String sql = "DELETE FROM attach2 WHERE uuid = ? ";
			
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, uuid);
			// 실행
			pstmt.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBManager2.close(con, pstmt);
		}
	} // deleteAttach method
	
}
